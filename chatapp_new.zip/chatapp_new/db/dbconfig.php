<?php
// Enter your Host, username, password, database below.
// I left password empty because i do not set password on localhost.
session_start();
$con = mysqli_connect("localhost","root","","chatapp");
// $con = mysqli_connect("localhost","id3682002_youandmeconvo","id3682002_youandmeconvo","youandmeconvo");
// Check connection
if (mysqli_connect_errno()) {
     echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
function get_row_by_id($id,$table) {
     global $con;
     $sql = "SELECT * FROM ".$table." WHERE `id`=".$id." LIMIT 1;";
     $hash = mysqli_query($con, $sql);
     if ($hash && mysqli_num_rows($hash) == 1) {
          return mysqli_fetch_assoc($hash);
     } else {
          return array();
     }
}
?>