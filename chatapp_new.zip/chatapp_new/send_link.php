<?php
require('db/dbconfig.php');
if(isset($_POST['submit_email']) && $_POST['email'])
{
  $email = $_POST['email'];
  $select = mysqli_query($con,"SELECT email,password FROM users WHERE email='$email'");
  if(mysqli_num_rows($select)==1)
  {
    while($row=mysqli_fetch_array($select))
    {
      $email= $row['email'];
      $pass=md5($row['password']);
    }
    $link="<a href='http://localhost/PROJECTS/chatapp/reset.php?key=".$email."&reset=".$pass."'>Click To Reset password</a>";
    require_once('phpmail/PHPMailerAutoload.php');
    $mail = new PHPMailer;
    $mail->CharSet =  "utf-8";
    $mail->IsSMTP();
    $mail->Host = "smtp.gmail.com";
    // enable SMTP authentication
    $mail->SMTPAuth = true;                  
    // GMAIL username
    $mail->Username = "coolnavesh@gmail.com";
    // GMAIL password
    $mail->Password = "Naveesh#97784";
    $mail->SMTPSecure = "ssl";  
    // sets GMAIL as the SMTP server
    
    // set the SMTP port for the GMAIL server
    $mail->Port = "587";
    $mail->From='coolnavesh@gmail.com';
    $mail->FromName='Navesh Kintali';
    $mail->AddAddress('kintalinaveesh1995@gmail.com');
    $mail->Subject  =  'Reset Password';
    $mail->IsHTML(true);
    $mail->Body    = 'Click On This Link to Reset Password '.$pass.'';
    if($mail->Send())
    {
      echo "Check Your Email and Click on the link sent to your email";
    }
    else
    {
      echo "Mail Error - >".$mail->ErrorInfo;
    }
  }  
}
?>