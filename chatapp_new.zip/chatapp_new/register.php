<!DOCTYPE html>
<html>
<head>
     <title>New</title>
     <link rel="shortcut icon" href="images/logo.png" />
     <link rel="shortcut icon" href="images/favicon.ico" >
   <link rel="icon" type="image/gif" href="images/animated_favicon1.gif" >
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.2/css/bootstrap.min.css" integrity="sha384-y3tfxAZXuh4HwSYylfB+J125MxIs6mR5FOHamPBG064zB+AFeWH94NdvaCBm8qnd" crossorigin="anonymous">

<link rel="stylesheet" href="css/style.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- Font Awsome -->
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

<!-- JQuery -->
<script  src="https://code.jquery.com/jquery-3.2.1.js" integrity="sha256-DZAnKJ/6XZ9si04Hgrsxu/8s717jcIzLy3oi35EouyE=" crossorigin="anonymous"></script>
</head>
<body>
     <div class="container">
        <div class="card card-container">
            <img id="profile-img" class="profile-img-card" src="images/logo.png" />
            <p id="profile-name" class="profile-name-card"></p>
            <form class="form-signin" action="verify.php" method="POST">
                <input type="text" name="username" id="inputUsername" class="form-control" placeholder="Username" required autofocus>
                <input type="email" name="email" id="inputEmail" class="form-control" placeholder="Email address" required>
                <input type="password" name="password" id="inputPassword" class="form-control" placeholder="Password" required>
                <input type="text" name="mobile" id="mobile" class="form-control" placeholder="Mobile no" required><br>
                <button class="btn btn-lg btn-primary btn-block btn-signin" type="submit" name="submit">Sign Up</button>
            </form><!-- /form -->
            <a href="index.php" class="newuser">
                Already register?
            </a>
        </div><!-- /card-container -->
    </div>
</body>
</html>