<?php
require 'PHPMailerAutoload.php';

$mail = new PHPMailer;

//Enable SMTP debugging. 
$mail->SMTPDebug = 0;                               
//Set PHPMailer to use SMTP.
$mail->isSMTP();            
//Set SMTP host name                          
$mail->Host = "smtp.gmail.com";
//Set this to true if SMTP host requires authentication to send email
$mail->SMTPAuth = true;                          
//Provide username and password     
$mail->Username = "abc684449@gmail.com";                 
$mail->Password = "Naveesh#97784";                           
//If SMTP requires TLS encryption then set it
$mail->SMTPSecure = "tls";                           
//Set TCP port to connect to 
$mail->Port = 587;     
ini_set('max_execution_time', 300);

$mail->From = "abc684449@gmail.com";
$mail->FromName = "ABC";

// $mail->addAddress("rekha@themeditube.com", "Rekha");
$mail->addAddress('kintalinaveesh1995@gmail.com', "Naveesh");
$mail->isHTML(true);

$mail->Subject = "Subject Text";
$mail->Body = "<i>Mail body in HTML</i>";
$mail->AltBody = "This is the plain text version of the email content";

if(!$mail->send()) 
{
    echo "Mailer Error: " . $mail->ErrorInfo;
} 
else 
{
    echo "Message has been sent successfully";
}


?>