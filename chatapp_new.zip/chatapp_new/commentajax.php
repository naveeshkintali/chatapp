<?php
     require('db/dbconfig.php');

     if(isset($_POST['user_comm'])) {
          $comment = mysqli_real_escape_string($con,$_POST['user_comm']);
          $from_id = mysqli_real_escape_string($con,$_SESSION['id']);
          $to_id = mysqli_real_escape_string($con,$_POST['to_id']);
          $insert = mysqli_query($con,"insert into comments (id,from_id,to_id,comment) values (NULL,".$from_id.",".$to_id.",'".$comment."');");
     } else {
          echo 0;
     }
?>