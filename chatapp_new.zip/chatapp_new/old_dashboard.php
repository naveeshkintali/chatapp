<?php
require('db/dbconfig.php');
if(!isset($_SESSION['email']) || empty($_SESSION['email'])) { 
    header('location:index.php');
}
 ?>
<!DOCTYPE html>
<html>
<head>
     <title>Dashboard</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" type="text/css" href="css/jquery.emojipicker.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.2.min.js"></script>
  <script type="text/javascript" src="js/jquery.emojipicker.js"></script>
<link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- Font Awsome -->
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  <!-- Emoji Data -->
  <link rel="stylesheet" type="text/css" href="css/jquery.emojipicker.tw.css">
  <script type="text/javascript" src="js/jquery.emojis.js"></script>
<script>
$(document).ready(function()
    {
        $(document).bind('keypress', function(e) {
            if(event.keyCode==13){
                 $('#my_form').submit();
                     $('.comment').val("");
             }
        });
     });
</script>
<script>
    var loading = 0;
    function set_id(id) {
        $("#to_id").val(id);
        autoRefresh_div();
    }
    function post() {
      var comment = $(".comment").val();
      var to_id = $("#to_id").val();
      if(comment != '' && to_id != '') {
        $.ajax({
          type: 'POST',
          url: 'commentajax.php',
          data: { user_comm:comment,to_id:to_id, },
          success: function (response) {
            // console.log(response);
             if(response == 0) {
                alert("Error Occured!");
             } else {
                $(".comment").val("");
             }
          }
        });
      }  
      return false;
    }
    function autoRefresh_div() {
       var to_id = $("#to_id").val();
       if(to_id != '' && to_id != 0) {
            if(loading == 0) {
                loading = 1;
                $.ajax({
                  type: 'POST',
                  url: 'load.php',
                  data: { to_id:to_id },
                  success: function (response) {
                        $("#rightblock").html(response);
                        loading = 0;
                  }
                });
            } else {
                setTimeout(function() {
                    autoRefresh_div();
                },1000);   
            }
       }
    }
    $(function() {
        setInterval(function() {
            autoRefresh_div();
        }, 2000);
    });

     $(document).ready(function(e) {

      $('#input-default').emojiPicker();

      $('#input-custom-size').emojiPicker({
        width: '300px',
        height: '200px'
      });

      $('#input-left-position').emojiPicker({
        position: 'left'
      });

      $('#create').click(function(e) {
        e.preventDefault();
        $('#text-custom-trigger').emojiPicker({
          width: '300px',
          height: '200px',
          button: false
        });
      });

      $('#toggle').click(function(e) {
        e.preventDefault();
        $('#text-custom-trigger').emojiPicker('toggle');
      });

      $('#destroy').click(function(e) {
        e.preventDefault();
        $('#text-custom-trigger').emojiPicker('destroy');
      })

      // keyup event is fired
      $(".emojiable-question, .emojiable-option").on("keyup", function () {
        //console.log("emoji added, input val() is: " + $(this).val());
      });

    });
</script>
</head>
<body>
    <!-- 
    Welcome Note
    Logout Link
     -->
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-6" style="font-size: 18px;color: white;float: left;padding: 15px;">
                <?php 
                $username = $_SESSION['username'];
                ?>
                Welcome: <?php echo $username; ?>
            </div>
            <div class="col-md-6 col-sm-6 col-xs-6">
                <a href="index.php" style="font-size: 18px;color: white;float: right;padding: 15px;">Logout
                </a>
            </div>
        </div>
    </div><br>
    <!-- closing
    Welcome Note
    Logout Link
     -->
     <div class="container">
         <div class="row">
             <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 leftblock" style="float: left;height:500px;overflow-y:auto;">
            <?php
                $sql = 'SELECT * FROM users';
                $result = mysqli_query($con, $sql);

                if (mysqli_num_rows($result) > 0) {
                while($row = mysqli_fetch_assoc($result)) {
                if($row['id'] == $_SESSION['id']) continue;
                echo "<span style='font-size:17px;' id='trigger'>".
                "<a style='color:white;cursor:pointer;padding:5px;' onclick='set_id(".$row['id'].");return false;' >".$row["username"]."</a>"."</span>". "<br>";
                }
                } else {
                echo "<p style=color:white;font-size:18px;>"."No users to display"."</p>";
                }
                mysqli_close($con);
            ?>
             </div>

             <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 rightblock">
                 <div style="background-color: transparent;color:white;overflow-y:auto;height:450px;font-size: 16px;padding: 15px;margin-bottom: 5px;" id="rightblock"></div>

                    <form method='POST' action="#" onsubmit="return post();" id="my_form" name="my_form" style="width:100%;margin-top: 20px;float: right;">
                        <div id="form-container">
                            <div class="form-text">
                                <input type="hidden" id="to_id" value=""/>
                                <textarea id="input-custom-size" class="emojiable-option comment"></textarea>
                            </div>
                            <div class="form-btn">
                                <input type="submit" value="Send" id="btn" name="btn"/>
                            </div>
                        </div>
                    </form>
             </div>
         </div>
     </div>
    <script type="text/javascript">
      var _gaq = _gaq || [];
      _gaq.push(['_setAccount', 'UA-36251023-1']);
      _gaq.push(['_setDomainName', 'jqueryscript.net']);
      _gaq.push(['_trackPageview']);
      (function() {
        var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
      })();

    </script>
</body>
</html>