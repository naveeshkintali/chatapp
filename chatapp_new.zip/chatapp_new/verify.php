<?php 
require('db/dbconfig.php');
     if (isset($_POST['submit'])) {
          $minlgth = 7;
          $username = $_POST['username'];
          $email = $_POST['email'];
          $password = $_POST['password'];
          $mobnumber = $_POST['mobile'];
// VALIDATION
          $emailval = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/';
          if ( $email=="") 
          {
               echo '<script type="text/javascript">'; 
               echo 'alert("Form Should Not Be Blank");'; 
               echo 'window.location.href = "signup/register.php";';
               echo '</script>'; die();
          }elseif($username == ""){
               echo '<script type="text/javascript">'; 
               echo 'alert("Please Provide Username");'; 
               echo 'window.location.href = "signup/register.php";';
               echo '</script>'; die();
          }elseif (strlen($username) < 4 || strlen($username) > 8 ) {
               echo '<script type="text/javascript">'; 
               echo 'alert("Username Should Be Between 4 To 8 Characters");'; 
               echo 'window.location.href = "signup/register.php";';
               echo '</script>'; die();
          } elseif(!preg_match($emailval, $email)) {
               echo '<script type="text/javascript">'; 
               echo 'alert("Email Is Invalid");'; 
               echo 'window.location.href = "signup/register.php";';
               echo '</script>'; die();
          }elseif ($password == "") {
               echo '<script type="text/javascript">'; 
               echo 'alert("Password Field Should Not Be Blank");'; 
               echo 'window.location.href = "signup/register.php";';
               echo '</script>'; die();
          }elseif (strlen($password) <= 8) {
               echo '<script type="text/javascript">'; 
               echo 'alert("Password Should Be More Than 8 Characters");'; 
               echo 'window.location.href = "signup/register.php";';
               echo '</script>'; die();
          }elseif($mobnumber ==""){
               echo '<script type="text/javascript">'; 
               echo 'alert("Mobile Number Should Not Be Blank");'; 
               echo 'window.location.href = "signup/register.php";';
               echo '</script>'; die();
          }
          // valid
          $query= mysqli_query($con,'SELECT * FROM users where email="'.$email.'" || username="'.$username.'" ');
          if (mysqli_num_rows($query) > 0) {
               echo '<script type="text/javascript">'; 
               echo 'alert("Email or Username  already registered.Please choose different email or username");'; 
               echo 'window.location.href = "signup/register.php";';
               echo '</script>';
          }
          else{

          $password = password_hash($password, PASSWORD_DEFAULT);

                $t = mysqli_query($con,"INSERT INTO users VALUES (NULL,'".$username."','".$email."','".$password."',
                    '".$mobnumber."');");
                if ($t) {
               echo '<script type="text/javascript">'; 
               echo 'alert("Successfully Registered");'; 
               echo 'window.location.href = "index.php";';
               echo '</script>';
               } else {
                    echo '<script type="text/javascript">'; 
                    echo 'alert("Sorry Something Went Wrong.Try Again.");'; 
                    echo 'window.location.href = "signup/register.php";';
                    echo '</script>';
               }
          }
     }
?>