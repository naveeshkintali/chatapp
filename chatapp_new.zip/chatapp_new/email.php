<?php
require('phpmail/class.phpmailer.php');
$mail = new PHPMailer();
$subject = "Test Mail using PHP mailer";
$content = "<b>This is a test mail using PHP mailer class.</b>";
$mail->IsSMTP();
$mail->SMTPDebug = 0;
$mail->SMTPAuth = TRUE;
$mail->SMTPSecure = "tls";
$mail->Port     = 465;  
$mail->Username = "coolnavesh@gmail.com";
$mail->Password = "Naveesh#97784";
$mail->Host     = "ssl://smtp.gmail.com";
$mail->Mailer   = "smtp";
$mail->AddAddress("coolnavesh@gmail.com");
$mail->Subject = $subject;
$mail->WordWrap   = TRUE;
$mail->MsgHTML($content);
$mail->IsHTML(true);

if(!$mail->Send()) 
	echo "Problem on sending mail";
else 
echo "Mail sent";
?>