<?php
     require('db/dbconfig.php');
     if(isset($_POST['submit'])){
      $_SESSION["name"] = $_POST["name"];  
      $_SESSION['last_login_timestamp'] = time();  
      header("location:index.php");       
     }
     if (isset($_POST['submit'])) {
          $email = htmlentities($_POST['email']);
          $password = htmlentities($_POST['password']);
// VALIDATION
          $emailval = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/';
          
          if ($email=="" || $password=="") {
               echo "please enter details."; die();
          } elseif(!preg_match($emailval, $email)) {
               echo "email is invalid"; die();
          } 
          $email = stripslashes($email);
          $password = stripslashes($password);    

          $sql = "SELECT * FROM users WHERE email = '" . $email . "' LIMIT 1;";
          $hash = mysqli_query($con, $sql);
          if ($hash && mysqli_num_rows($hash) == 1) {
                    $user = mysqli_fetch_assoc($hash);
               $pass = $user['password'];
               if (password_verify($password, $pass)) {
                   $_SESSION['id'] = $user['id'];
                   $_SESSION['email'] = $user['email'];
                   $_SESSION['username'] = $user['username'];
                   header("Location:dashboard.php");
                   die();
               } else {
                   echo '<script type="text/javascript">'; 
                   echo 'alert("Wrong password");'; 
                   echo 'window.location.href = "index.php";';
                   echo '</script>';
                  die();
               }
          }
          else{
               echo '<script type="text/javascript">'; 
               echo 'alert("User not found.Please register");'; 
               echo 'window.location.href = "register.php";';
               echo '</script>';die();
          }
          
     }
     ?>