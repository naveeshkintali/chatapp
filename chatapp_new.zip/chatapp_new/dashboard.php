<?php 
require('db/dbconfig.php');

if(isset($_SESSION["email"]))  
    {  
        if((time() - $_SESSION['last_login_timestamp']) > 60*60)  
        {  
            echo '<script type="text/javascript">'; 
            echo 'alert("Session Expired.Please login again");'; 
            echo 'window.location.href = "index.php";';
            echo '</script>'; die();
        }  
        else  
        {  
            $_SESSION['last_login_timestamp'] = time();
        }  
    }  
    else  
    {  
    header('location:login.php'); die();  
}  
if(!isset($_SESSION['email']) || empty($_SESSION['email'])) { 
    header('location:index.php');
}
 ?>
<html>
<head>
  <title>Dashboard</title>
     <link rel="shortcut icon" href="images/logo.png" />
     <link rel="shortcut icon" href="images/favicon.ico" >
   <link rel="icon" type="image/gif" href="images/animated_favicon1.gif" >
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<!-- <link rel="stylesheet" type="text/css" href="css/style.css"> -->
<link rel="stylesheet" type="text/css" href="css/jquery.emojipicker.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.2.min.js"></script>
  <script type="text/javascript" src="js/jquery.emojipicker.js"></script>
<link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">

<!-- Latest compiled JavaScript -->
<!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> -->
<!-- Font Awsome -->
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  <!-- Emoji Data -->
  <link rel="stylesheet" type="text/css" href="css/jquery.emojipicker.tw.css">
  <script type="text/javascript" src="js/jquery.emojis.js"></script>
<script>
$(document).ready(function()
    {
        $(document).bind('keypress', function(e) {
            if(event.keyCode==13){
                 $('#my_form').submit();
                     $('.comment').val("");
             }
        });
     });
</script>
<script>
    var loading = 0;
    function set_id(id) {
        $("#to_id").val(id);
        autoRefresh_div();
    }
    function post() {
      var comment = $(".comment").val();
      var to_id = $("#to_id").val();
      if(comment != '' && to_id != '') {
        $.ajax({
          type: 'POST',
          url: 'commentajax.php',
          data: { user_comm:comment,to_id:to_id, },
          success: function (response) {
            // console.log(response);
             if(response == 0) {
                alert("Error Occured!");
             } else {
                $(".comment").val("");
             }
          }
        });
      }  
      return false;
    }
    function autoRefresh_div() {
       var to_id = $("#to_id").val();
       if(to_id != '' && to_id != 0) {
            if(loading == 0) {
                loading = 1;
                $.ajax({
                  type: 'POST',
                  url: 'load.php',
                  data: { to_id:to_id },
                  success: function (response) {
                        $("#rightblock").html(response);
                        loading = 0;
                  }
                });
            } else {
                setTimeout(function() {
                    autoRefresh_div();
                },1000);   
            }
       }
    }
    $(function() {
        setInterval(function() {
            autoRefresh_div();
        }, 2000);
    });

     $(document).ready(function(e) {

      $('#input-default').emojiPicker();

      $('#input-custom-size').emojiPicker({
        width: '300px',
        height: '200px'
      });

      $('#input-left-position').emojiPicker({
        position: 'left'
      });

      $('#create').click(function(e) {
        e.preventDefault();
        $('#text-custom-trigger').emojiPicker({
          width: '300px',
          height: '200px',
          button: false
        });
      });

      $('#toggle').click(function(e) {
        e.preventDefault();
        $('#text-custom-trigger').emojiPicker('toggle');
      });

      $('#destroy').click(function(e) {
        e.preventDefault();
        $('#text-custom-trigger').emojiPicker('destroy');
      })

      // keyup event is fired
      $(".emojiable-question, .emojiable-option").on("keyup", function () {
        // console.log("emoji added, input val() is: " + $(this).val());    
      });

    });
    window.setInterval(function() {
    var elem = document.getElementById('rightblock');
    elem.scrollTop = elem.scrollHeight;
    },1000);
</script>
<style>
@import url('https://fonts.googleapis.com/css?family=Roboto');
.container{width: 100%;}
.emojiPickerIcon{margin-top: -0.7em;}
html,
body,
div,
span {
  width: 100%;
  overflow: hidden;
  padding: 0;
  margin: 0;
  box-sizing: border-box;
}

body {
  background: url("http://shurl.esy.es/y") no-repeat fixed center;
  background-size: cover;
font-family: 'Roboto', sans-serif;
}

.fa-2x {
  font-size: 1.5em;
}
.container{
  max-width: 100%;
}

.app {
  position: relative;
  overflow: hidden;
  /*height: calc(100% - 38px);*/
  margin: auto;
  padding: 0;
  box-shadow: 0 1px 1px 0 rgba(0, 0, 0, .06), 0 2px 5px 0 rgba(0, 0, 0, .2);
}

.app-one {
  background-color: #f7f7f7;
  height: 100%;
  overflow: hidden;
  margin: 0;
  padding: 0;
  box-shadow: 0 1px 1px 0 rgba(0, 0, 0, .06), 0 2px 5px 0 rgba(0, 0, 0, .2);
}

.side {
  padding: 0;
  margin: 0;
  height: 100%;
}
.side-one {
  padding: 0;
  margin: 0;
  height: 100%;
  width: 100%;
  z-index: 1;
  position: relative;
  display: block;
  top: 0;
}

.side-two {
  padding: 0;
  margin: 0;
  height: 100%;
  width: 100%;
  z-index: 2;
  position: relative;
  top: -100%;
  left: -100%;
  -webkit-transition: left 0.3s ease;
  transition: left 0.3s ease;

}


.heading {
  padding: 10px 16px 10px 15px;
  margin: 0;
  height: 60px;
  width: 100%;
  background-color: #a293f0;
  z-index: 1000;
}

.heading-avatar {
  padding: 0;
  cursor: pointer;

}

.heading-avatar-icon img {
  border-radius: 50%;
  height: 40px;
  width: 40px;
}

.heading-name {
  padding: 0 !important;
  cursor: pointer;
}

.heading-name-meta {
  font-weight: 700;
  font-size: 100%;
  padding: 5px;
  padding-bottom: 0;
  text-align: left;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: #000;
  display: block;
}
.heading-online {
  display: none;
  padding: 0 5px;
  font-size: 12px;
  color: #93918f;
}
.heading-compose {
  padding: 0;
}

.heading-compose i {
  text-align: center;
  padding: 5px;
  color: #93918f;
  cursor: pointer;
}

.heading-dot {
  padding: 0;
  margin-left: 10px;
}

.heading-dot i {
  text-align: right;
  padding: 5px;
  color: #93918f;
  cursor: pointer;
}

.searchBox {
  padding: 0 !important;
  margin: 0 !important;
  height: 60px;
  width: 100%;
}

.searchBox-inner {
  height: 100%;
  width: 100%;
  padding: 10px !important;
  background-color: #838182;
}


/*#searchBox-inner input {
  box-shadow: none;
}*/

.searchBox-inner input:focus {
  outline: none;
  border: none;
  box-shadow: none;
}

.sideBar {
  padding: 0 !important;
  margin: 0 !important;
  background-color: #838182;
  overflow-y: auto;
  height: calc(100% - 120px);
}

.sideBar-body {
  position: relative;
  margin: 0 !important;
  cursor: pointer;
}
.sideBar-main{
  width: 100%;
}
/*.sideBar-main:hover {
  background-color: #f2f2f2;
}*/

.sideBar-avatar {
  text-align: center;
  padding: 0.5em;
}
.sideBar-avatar:hover{
  background-color: #f2f2f2;
}

.avatar-icon img {
  border-radius: 50%;
  height: 49px;
  width: 49px;
}

.sideBar-main {
  padding: 0 !important;
}

.sideBar-main .row {
  padding: 0 !important;
  margin: 0 !important;
}

.name-meta {
  font-size: 100%;
  padding: 1% !important;
  text-align: left;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: #000;
}

.sideBar-time {
  padding: 10px !important;
}

.time-meta {
  text-align: right;
  font-size: 12px;
  padding: 1% !important;
  color: rgba(0, 0, 0, .4);
  vertical-align: baseline;
}

/*New Message*/

.newMessage {
  padding: 0 !important;
  margin: 0 !important;
  height: 100%;
  position: relative;
  left: -100%;
}
.newMessage-heading {
  padding: 10px 16px 10px 15px !important;
  margin: 0 !important;
  height: 100px;
  width: 100%;
  background-color: #00bfa5;
  z-index: 1001;
}

.newMessage-main {
  padding: 10px 16px 0 15px !important;
  margin: 0 !important;
  height: 60px;
  margin-top: 30px !important;
  width: 100%;
  z-index: 1001;
  color: #fff;
}

.newMessage-title {
  font-size: 18px;
  font-weight: 700;
  padding: 10px 5px !important;
}
.newMessage-back {
  text-align: center;
  vertical-align: baseline;
  padding: 12px 5px !important;
  display: block;
  cursor: pointer;
}
.newMessage-back i {
  margin: auto !important;
}

.composeBox {
  padding: 0 !important;
  margin: 0 !important;
  height: 60px;
  width: 100%;
}

.composeBox-inner {
  height: 100%;
  width: 100%;
  padding: 10px !important;
  background-color: #fbfbfb;
}

.composeBox-inner input:focus {
  outline: none;
  border: none;
  box-shadow: none;
}

.compose-sideBar {
  padding: 0 !important;
  margin: 0 !important;
  background-color: #fff;
  overflow-y: auto;
  border: 1px solid #f7f7f7;
  height: calc(100% - 160px);
}

/*Conversation*/

.conversation {
  padding: 0 !important;
  margin: 0 !important;
  height: 100%;
  /*width: 100%;*/
  border-left: 1px solid rgba(0, 0, 0, .08);
  /*overflow-y: auto;*/
}

.message {
  padding: 0 !important;
  margin: 0 !important;
  background: url("w.jpg") no-repeat fixed center;
  background-size: cover;
  overflow-y: auto;
  border: 1px solid #f7f7f7;
  height: calc(100% - 120px);
}
.message-previous {
  margin : 0 !important;
  padding: 0 !important;
  height: auto;
  width: 100%;
}
.previous {
  font-size: 15px;
  text-align: center;
  padding: 10px !important;
  cursor: pointer;
}

.previous a {
  text-decoration: none;
  font-weight: 700;
}

.message-body {
  margin: 0 !important;
  padding: 0 !important;
  width: auto;
  height: auto;
}

.message-main-receiver {
  /*padding: 10px 20px;*/
  max-width: 60%;
}

.message-main-sender {
  padding: 3px 20px !important;
  margin-left: 40% !important;
  max-width: 60%;
}

.message-text {
  margin: 0 !important;
  padding: 5px !important;
  word-wrap:break-word;
  font-weight: 200;
  font-size: 14px;
  padding-bottom: 0 !important;
}

.message-time {
  margin: 0 !important;
  margin-left: 50px !important;
  font-size: 12px;
  text-align: right;
  color: #9a9a9a;

}

.receiver {
  width: auto !important;
  padding: 4px 10px 7px !important;
  border-radius: 10px 10px 10px 0;
  background: #ffffff;
  font-size: 12px;
  text-shadow: 0 1px 1px rgba(0, 0, 0, .2);
  word-wrap: break-word;
  display: inline-block;
}

.sender {
  float: right;
  width: auto !important;
  background: #dcf8c6;
  border-radius: 10px 10px 0 10px;
  padding: 4px 10px 7px !important;
  font-size: 12px;
  text-shadow: 0 1px 1px rgba(0, 0, 0, .2);
  display: inline-block;
  word-wrap: break-word;
}


/*Reply*/

.reply {
  height: auto;
  width: 100%;
  background-color: #838182;
  margin: 0 !important;
  z-index: 1000;
}

.reply-emojis {
  padding: 5px !important;
}

.reply-emojis i {
  text-align: center;
  padding: 5px 5px 5px 5px !important;
  color: #93918f;
  cursor: pointer;
}

.reply-recording {
  padding: 5px !important;
}

.reply-recording i {
  text-align: center;
  padding: 5px !important;
  color: #93918f;
  cursor: pointer;
}

.reply-send {
  padding: 5px !important;
}

.reply-send i {
  text-align: center;
  padding: 5px !important;
  color: #93918f;
  cursor: pointer;
}

.reply-main {
  padding: 2px 5px !important;
}
#my_form{
  position: absolute;
  bottom: 0px;
  width: 100%;
}
input::-webkit-input-placeholder {
color: white !important;
}
 
input:-moz-placeholder { /* Firefox 18- */
color: white !important;  
}
 
input::-moz-placeholder {  /* Firefox 19+ */
color: white !important;  
}
 
input:-ms-input-placeholder {  
color: white !important;  
}
.form-control{
  display: block;

width: 100%;

height: 34px;

padding: 6px 12px;

font-size: 14px;

line-height: 1.42857143;

color: white;

background-color: transparent;

background-image: none;

border: transparent;

border-radius: 4px;

-webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);

box-shadow: inset 0 1px 1px rgba(0,0,0,.075);

-webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;

-o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;

transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
}
.reply-main textarea {
  width: 100%;
  resize: none;
  overflow: hidden;
  padding: 5px !important;
  outline: none;
  border: none;
  text-indent: 5px;
  box-shadow: none;
  height: 100%;
  font-size: 16px;
}

.reply-main textarea:focus {
  outline: none;
  border: none;
  text-indent: 5px;
  box-shadow: none;
}

@media screen and (max-width: 700px) {
  .app {
    top: 0;
    height: 100%;
  }
  .heading {
    height: 70px;
    background-color: #009688;
  }
  .fa-2x {
    font-size: 2.3em !important;
  }
  .heading-avatar {
    padding: 0 !important;
  }
  .heading-avatar-icon img {
    height: 50px;
    width: 50px;
  }
  .heading-compose {
    padding: 5px !important;
  }
  .heading-compose i {
    color: #fff;
    cursor: pointer;
  }
  .heading-dot {
    padding: 5px !important;
    margin-left: 10px !important;
  }
  .heading-dot i {
    color: #fff;
    cursor: pointer;
  }
  .sideBar {
    height: calc(100% - 130px);
  }
  .sideBar-body {
    height: 80px;
  }
  .sideBar-avatar {
    text-align: left;
    padding: 0 8px !important;
  }
  .avatar-icon img {
    height: 55px;
    width: 55px;
  }
  .sideBar-main {
    padding: 0 !important;
  }
  .sideBar-main .row {
    padding: 0 !important;
    margin: 0 !important;
  }
  .sideBar-name {
    padding: 0px !important;
  }
  .name-meta {
    font-size: 16px;
    padding: 5% !important;
  }
  .sideBar-time {
    padding: 10px !important;
  }
  .time-meta {
    text-align: right;
    font-size: 14px;
    padding: 4% !important;
    color: rgba(0, 0, 0, .4);
    vertical-align: baseline;
  }
  /*Conversation*/
  .conversation {
    padding: 0 !important;
    margin: 0 !important;
    height: auto;
    /*width: 100%;*/
    border-left: 1px solid rgba(0, 0, 0, .08);
    /*overflow-y: auto;*/
  }
  .message {
    height: calc(100% - 140px);
  }
  .reply {
    height: 70px;
  }
  .reply-emojis {
    padding: 5px 0 !important;
  }
  .reply-emojis i {
    padding: 5px 2px !important;
    font-size: 1.8em !important;
  }
  .reply-main {
    padding: 2px 8px !important;
  }
  .reply-main textarea {
    padding: 8px !important;
    font-size: 18px;
  }
  .reply-recording {
    padding: 5px 0 !important;
  }
  .reply-recording i {
    padding: 5px 0 !important;
    font-size: 1.8em !important;
  }
  .reply-send {
    padding: 5px 0 !important;
  }
  .reply-send i {
    padding: 5px 2px 5px 0 !important;
    font-size: 1.8em !important;
  }
}
.sent{
  width: 51%;
  padding-left:0.2em;
  float: right;
  /*background-color: #aea1ed;*/
}
.received{
  margin-top: 0.5em;
  width: 51%;
  float: left;
  padding-left:0.2em;
  border-radius: 5px;
  /*background-color: #959396;*/
}
.heading-name-meta{
  color:white;
}
.glyphicon.glyphicon-send{
  color:white;
}
form{
  border-top: 1px solid white;
}
</style>
</head>
<body>
<div class="container app">
  <div class="row app-one">
    <div class="col-sm-3 side">
      <div class="side-one">
        <div class="row heading">
          <div class="col-md-12 col-sm-12 col-xs-12 heading-avatar">
            <div class="heading-avatar-icon" style="font-weight:600;font-size:22px;color: white;text-align: center;">
             <?php 
                $username = $_SESSION['username'];
                ?>
                Welcome: <?php echo $username; ?>
            </div>
          </div>
        </div>
        <div class="row sideBar">
          <div class="row sideBar-body">
            <div class="col-sm-9 col-xs-9 sideBar-main">
              <div class="row">
                <div class="col-sm-8 col-xs-8 sideBar-name" style="width:100%;padding: 0px !important;">
                   <?php
                $sql = 'SELECT * FROM users';
                $result = mysqli_query($con, $sql);

                if (mysqli_num_rows($result) > 0) {
                while($row = mysqli_fetch_assoc($result)) {
                if($row['id'] == $_SESSION['id']) continue;
                echo "
                <div class='col-sm-3 col-xs-3 sideBar-avatar' style='width:100%;'>
                <a style='float:left;font-size:18px;color:white;text-decoration: none;cursor:pointer;' onclick='set_id(".$row['id'].");return false;' >"."<img src='https://bootdey.com/img/Content/avatar/avatar6.png' 
                class='avatar-icon' style='width:20%;border-radius:50%;float:left;'>"
                ."<div style='width:50%;margin-top:1.5rem;
                border-radius:8px;margin-bottom:2px;text-align:center;height:2em;float:left;' id='trigger'>".$row["username"]."</div>"."</a>"."</div>";
                }
                } else {
                echo "<p style=color:black;font-size:18px;>"."No users to display"."</p>";
                }
                mysqli_close($con);
            ?>
                </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-sm-9 conversation">
      <div class="row heading">
        <div class="col-sm-2 col-md-1 col-xs-3 heading-avatar">
          <div class="heading-avatar-icon">
            <img src="https://bootdey.com/img/Content/avatar/avatar6.png">
          </div>
        </div>
        <div class="col-sm-4 col-xs-7 heading-name">
          <a class="heading-name-meta">John Doe
          </a>
          <span class="heading-online">Online</span>
        </div>
        <div class="col-sm-4 col-xs-1  heading-dot pull-right">
          <a href="logout.php" style="font-size: 18px;color: white;float: right;padding: 10px;">Logout
                </a>
        </div>
      </div>
      <div style="background-color: #838182;color:white;overflow-y:auto;height:470px;font-size: 16px;padding: 15px;" id="rightblock">

        <picture style="margin:0 auto;">
          <source media="(min-width: 650px)" srcset="images/logo.png">
          <source media="(min-width: 465px)" srcset="images/logo.png">
          <img src="images/logo.png" alt="logo" style="width:auto;margin:auto;display:block;margin-top:5em;">
          <p style="margin-left:18em;">
          Do not disconnect your WIFI or Internet connection  
        </p>
        </picture>
      </div>

    <form method='POST' action="#" onsubmit="return post();" id="my_form" name="my_form">
      <div class="row reply">
        <div class="col-sm-10 col-xs-9 reply-main">
          <input type="hidden" id="to_id" value=""/>
          <input type="text" name="text" id="input-custom-size" class="comment form-control" rows="1" id="comment" placeholder="Type a message...">
        </div>
        <div class="col-sm-1 col-xs-1 reply-send form-btn">
          <button id="btn" name="btn" type="submit" class="btn btn-default btn-sm send" style="background: transparent;border: 0px;font-size: 20px;float: right;">
          <span class="glyphicon glyphicon-send"></span>
        </button>
        </div>
      </div>
    </form>
    </div>
  </div>
</div>
</body>
</html>