<?php 
session_start();
require('db/dbconfig.php');
if(!isset($_SESSION['email']) || empty($_SESSION['email'])) { 
    header('location:index.php');
}
 ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Lets Chat</title>
<head>
     <title>Dashboard</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<!-- <link rel="stylesheet" type="text/css" href="css/style.css"> -->
<link rel="stylesheet" type="text/css" href="css/jquery.emojipicker.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.2.min.js"></script>
  <script type="text/javascript" src="js/jquery.emojipicker.js"></script>
<link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- Font Awsome -->
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  <!-- Emoji Data -->
  <link rel="stylesheet" type="text/css" href="css/jquery.emojipicker.tw.css">
  <script type="text/javascript" src="js/jquery.emojis.js"></script>
<script>
$(document).ready(function()
    {
        $(document).bind('keypress', function(e) {
            if(event.keyCode==13){
                 $('#my_form').submit();
                     $('.comment').val("");
             }
        });
     });
</script>
<script>
    var loading = 0;
    function set_id(id) {
        $("#to_id").val(id);
        autoRefresh_div();
    }
    function post() {
      var comment = $(".comment").val();
      var to_id = $("#to_id").val();
      if(comment != '' && to_id != '') {
        $.ajax({
          type: 'POST',
          url: 'commentajax.php',
          data: { user_comm:comment,to_id:to_id, },
          success: function (response) {
            // console.log(response);
             if(response == 0) {
                alert("Error Occured!");
             } else {
                $(".comment").val("");
             }
          }
        });
      }  
      return false;
    }
    function autoRefresh_div() {
       var to_id = $("#to_id").val();
       if(to_id != '' && to_id != 0) {
            if(loading == 0) {
                loading = 1;
                $.ajax({
                  type: 'POST',
                  url: 'load.php',
                  data: { to_id:to_id },
                  success: function (response) {
                        $("#rightblock").html(response);
                        loading = 0;
                  }
                });
            } else {
                setTimeout(function() {
                    autoRefresh_div();
                },1000);   
            }
       }
    }
    $(function() {
        setInterval(function() {
            autoRefresh_div();
        }, 2000);
    });

     $(document).ready(function(e) {

      $('#input-default').emojiPicker();

      $('#input-custom-size').emojiPicker({
        width: '300px',
        height: '200px'
      });

      $('#input-left-position').emojiPicker({
        position: 'left'
      });

      $('#create').click(function(e) {
        e.preventDefault();
        $('#text-custom-trigger').emojiPicker({
          width: '300px',
          height: '200px',
          button: false
        });
      });

      $('#toggle').click(function(e) {
        e.preventDefault();
        $('#text-custom-trigger').emojiPicker('toggle');
      });

      $('#destroy').click(function(e) {
        e.preventDefault();
        $('#text-custom-trigger').emojiPicker('destroy');
      })

      // keyup event is fired
      $(".emojiable-question, .emojiable-option").on("keyup", function () {
        //console.log("emoji added, input val() is: " + $(this).val());
      });

    });
</script>
<style>
*{margin:0px; padding:0px;font-family: Helvetica, Arial, sans-serif;}
#logout{width:60px; height:20px; position:absolute; top:6px; right:20px; margin-bottom:40px; text-align:center; color:#fff}
#container{width:75%; height:auto; position:relative; top:8px; margin:auto;}

#session-name{width:100%; height:36px; margin-bottom:30px; font-size:20px}
.session-text{width:300px; height:30px;padding:6px 10px;margin: 8px 0;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box; font-size:24px}

#result-wrapper{width:100%; margin:auto; height:450px;}
#result{height:450px; overflow:scroll;overflow-x: hidden;}

#form-container{width:100%; margin:auto; height:80px;}
.form-text{float:left; width:85%; height:80px;}
#comment{width:100%; height:79px; resize:none;}
.form-btn{float:left; width:15%; height:80px;}
#btn{border:none; height:80px; width:100%; background:tomato; color:#fff; font-size:22px}

.chats{width:100%; margin-bottom:6px;}
.chats strong{color:#6d84b4}
.chats p{ font-size:14px; color:#aaa; margin-right:10px}
</style>
</head>
<body>
<div id="logout">
    <a href="logout.php" style="text-decoration:none"><i class="fa fa-sign-out" aria-hidden="true"></i>Logout</a>
</div>

<div id="container">

    <div id="session-name">
        Your Name: <input type="text" value="<?= $_SESSION['uname'] ?>" class="session-text" disabled>
    </div>

    <div id="result-wrapper">
        <div id="result">
            <?php
                include("load.php");
            ?>
        </div>          
    </div>

    <form method='post' action="#" onsubmit="return post();" id="my_form" name="my_form">
        <div id="form-container">
            <div class="form-text">
                <input type="text" style="display:none" id="username" value="<?= $_SESSION['uname'] ?>">
                <textarea id="comment"></textarea>
            </div>
            <div class="form-btn">
                <input type="submit" value="Send" id="btn" name="btn"/>
            </div>
        </div>
    </form>
</div>
</body>
</html>