 <?php
     require('db/dbconfig.php');
     $to_id = $_POST['to_id'];
     $user = get_row_by_id($to_id,'users');
     if(!is_numeric($to_id) && !empty($user)) { die(); }
     $from_id = $_SESSION['id'];
     $me = get_row_by_id($from_id,'users');
     $sql = 'select * from comments where (`to_id`='.$to_id.' AND `from_id`='.$from_id.') OR (`to_id`='.$from_id.' AND `from_id`='.$to_id.');';
     $result = mysqli_query($con, $sql);
     if (mysqli_num_rows($result) > 0) {
          while($row=mysqli_fetch_array($result)) {
               $name = ($row['from_id'] == $from_id) ? $me['username'] : $user['username'] ;
               $from_or_to = ($row['from_id'] == $from_id) ? "sent" : "received" ;
?>
               <div class="chats <?php echo $from_or_to; ?>" ><strong><?php echo $name ?></strong><br /><?php
                    echo "<div style='word-wrap: break-word;color:white;background-color:#959396;
                    padding:5px;border-radius:5px;font-weight:450'>";
                    echo $row['comment'];
                    echo "</div>";
                ?>
           </div>
<?php
          }
     } else {
          echo "No messages found!";
     }
?>