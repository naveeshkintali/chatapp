-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 19, 2017 at 03:39 PM
-- Server version: 10.1.24-MariaDB
-- PHP Version: 7.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chatapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `from_id` int(11) NOT NULL,
  `to_id` int(11) NOT NULL,
  `comment` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `from_id`, `to_id`, `comment`) VALUES
(19, 20, 21, 'wafdsa'),
(20, 20, 21, 'fdsgfsdg'),
(21, 25, 20, 'sdgfsdf'),
(22, 25, 20, 'sadfas'),
(23, 25, 20, 'adfsdfsdfsdfsdf'),
(24, 25, 20, 'sadfsdfs'),
(25, 20, 25, 'dsfsaf'),
(26, 25, 20, 'sdfsdfgfsd'),
(27, 25, 20, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Temporibus officiis neque eligendi ratione'),
(28, 25, 20, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Temporibus officiis neque eligendi ratione'),
(29, 25, 20, 'lkfjkn sd'),
(30, 25, 20, 'mkhsd'),
(31, 25, 20, 'jksd'),
(32, 25, 20, '\nnkjjs'),
(33, 25, 20, 'apple'),
(34, 25, 20, ' fkjfkj s'),
(35, 25, 20, 's d'),
(36, 25, 20, 'apple'),
(37, 25, 20, 'mhss'),
(38, 25, 20, '\napple'),
(39, 25, 20, 'boy'),
(40, 25, 20, '\nðŸ˜ƒðŸ‘®ðŸ˜ƒ'),
(41, 25, 20, 'ðŸŽ¼ðŸŽ¼ðŸŽ¼ðŸŽ¼ðŸŽ¼ðŸŽ¼'),
(42, 25, 20, '\nðŸ‡¸ðŸ‡¿ðŸ‡¹ðŸ‡³ðŸ‡¹ðŸ‡³ðŸ‡¹ðŸ‡´ðŸ‡¹ðŸ‡´ðŸ‡¹ðŸ‡´ðŸ‡¹ðŸ‡·'),
(43, 25, 20, 'ðŸ’™ðŸ’”â˜®'),
(44, 25, 20, 'ðŸ’”â˜®ðŸ’”â˜®ðŸ’”â˜®ðŸ’”â˜®ðŸ’”â˜®ðŸ’”â˜®ðŸ’”â˜®'),
(45, 20, 25, 'hi what happened'),
(46, 21, 21, 'â˜®ðŸ’”ðŸ’”â˜®'),
(47, 21, 21, 'nhsakc'),
(48, 21, 25, 'â˜®â˜®â˜®â˜®â˜®â˜®â˜®â˜®â˜®'),
(49, 25, 21, 'ðŸŒ“ðŸŒ“ðŸŒ“ðŸŒ“ðŸŒ“ðŸŒ“ðŸŒ“ðŸŒ“'),
(50, 25, 20, 'h,knndðŸŒ“ðŸŒ“ðŸŒ“ðŸŒ“ðŸŒ“ðŸŒ“ðŸŒ“'),
(51, 25, 20, 'â˜ºðŸ˜ŒðŸ˜ŒðŸ˜ŒðŸ˜ŒðŸ˜ŒðŸ˜Œ'),
(53, 25, 28, 'mhsk'),
(54, 28, 25, 'kmhnak'),
(55, 28, 21, 'kjjsssd'),
(56, 25, 21, 'mbss\n'),
(57, 21, 28, ',nkhsd'),
(58, 25, 29, 'apple');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(75) NOT NULL,
  `email` varchar(75) NOT NULL,
  `password` text NOT NULL,
  `mobnumber` varchar(75) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `mobnumber`) VALUES
(20, 'naveesh', 'k.naveesh2014@vit.ac.in', '$2y$10$Q0l5z5NWTGhesAWYjCPyKe8jm7quaT8iFQnx9jlFpMVQXZ8mnDZ3S', '9944817722'),
(21, 'nav', 'kintalinaveesh1995@gmail.com', '$2y$10$Sn9suV1uLcV6/wv84TvhHe/HlCGXkM1nGgpSs3hPFq16O.1YM9dby', '9944817722'),
(25, 'vvv', 'coolnavesh@gmail.com', '$2y$10$V52b2tRM/cjbtbU70c4Ap.AFo4bszVgGgvXD7O1g12EIhmgd.mwa.', '9955887744'),
(28, 'apple', 'apple@gmail.com', '$2y$10$7vVMlfpKtXufuPaXYcfTC.mGWWjgcgCvn1b9kpSoMtCVr5SBrj4uO', '9944817722'),
(29, 'cat', 'cat@gmail.com', '$2y$10$Ym3YUp1zK2sJOmBLDPEeEu1bQOLZonoZmFlYQUlaJ/Dnl0u9mY2y.', '9944817722');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `from_id` (`from_id`),
  ADD KEY `to_id` (`to_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `from_id_link` FOREIGN KEY (`from_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `to_id_link` FOREIGN KEY (`to_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
